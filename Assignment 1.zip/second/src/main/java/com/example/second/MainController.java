package com.example.second;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.chart.*;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;

import java.util.List;

public class MainController {

    @FXML
    private Button tableViewButton;

    @FXML
    private Button barChartButton;

    @FXML
    private Button pieChartButton;

    @FXML
    private TableView<VideoGame> tableView;

    @FXML
    private BarChart<String, Number> barChart;

    @FXML
    private PieChart pieChart;

    private List<VideoGame> gamesList;

    public void initData(List<VideoGame> gamesList) {
        this.gamesList = gamesList;

        tableViewButton.setOnAction(event -> displayTableView());
        barChartButton.setOnAction(event -> displayBarChart());
        pieChartButton.setOnAction(event -> displayPieChart());

        initTableView();
        initBarChart();
        initPieChart();
    }

    private void initTableView() {
        TableColumn<VideoGame, String> consoleNameColumn = new TableColumn<>("Console Name");
        consoleNameColumn.setCellValueFactory(new PropertyValueFactory<>("consoleName"));

        TableColumn<VideoGame, Integer> gameCountColumn = new TableColumn<>("Game Count");
        gameCountColumn.setCellValueFactory(new PropertyValueFactory<>("gameCount"));

        tableView.getColumns().addAll(consoleNameColumn, gameCountColumn);

        ObservableList<VideoGame> data = FXCollections.observableArrayList(gamesList);
        tableView.setItems(data);
    }

    private void initBarChart() {
        XYChart.Series<String, Number> series = new XYChart.Series<>();
        for (VideoGame game : gamesList) {
            series.getData().add(new XYChart.Data<>(game.getConsoleName(), game.getGameCount()));
        }
        barChart.getData().add(series);
    }

    private void initPieChart() {
        ObservableList<PieChart.Data> pieChartData = FXCollections.observableArrayList();
        for (VideoGame game : gamesList) {
            pieChartData.add(new PieChart.Data(game.getConsoleName(), game.getGameCount()));
        }
        pieChart.setData(pieChartData);
    }

    private void displayTableView() {
        tableView.setVisible(true);
        barChart.setVisible(false);
        pieChart.setVisible(false);
    }

    private void displayBarChart() {
        tableView.setVisible(false);
        barChart.setVisible(true);
        pieChart.setVisible(false);
    }

    private void displayPieChart() {
        tableView.setVisible(false);
        barChart.setVisible(false);
        pieChart.setVisible(true);
    }
}