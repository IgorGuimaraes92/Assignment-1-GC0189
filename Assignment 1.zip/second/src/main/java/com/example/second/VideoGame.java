package com.example.second;

import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;

public class VideoGame {
    private final SimpleStringProperty consoleName;
    private final SimpleIntegerProperty year;
    private final SimpleIntegerProperty gameCount;

    public VideoGame(String consoleName, int year, int gameCount) {
        this.consoleName = new SimpleStringProperty(consoleName);
        this.year = new SimpleIntegerProperty(year);
        this.gameCount = new SimpleIntegerProperty(gameCount);
    }

    public String getConsoleName() {
        return consoleName.get();
    }

    public SimpleStringProperty consoleNameProperty() {
        return consoleName;
    }

    public int getYear() {
        return year.get();
    }

    public SimpleIntegerProperty yearProperty() {
        return year;
    }

    public int getGameCount() {
        return gameCount.get();
    }

    public SimpleIntegerProperty gameCountProperty() {
        return gameCount;
    }
}