package com.example.second;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class DataFetcher {

    public static List<VideoGame> fetchLOTRGames() {
        List<VideoGame> gamesList = new ArrayList<>();
        try {
            Connection connection = DatabaseConnection.getConnection();
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery("SELECT * FROM lord_of_the_rings_games");

            while (resultSet.next()) {
                String consoleName = resultSet.getString("console_name");
                int gameCount = resultSet.getInt("game_count");
                int year = resultSet.getInt("year");

                gamesList.add(new VideoGame(consoleName, year, gameCount));
            }
            connection.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return gamesList;
    }
}