package com.example.second;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.stage.Stage;

import java.util.List;

public class Main extends Application {

    private List<VideoGame> gamesList;

    @Override
    public void start(Stage primaryStage) {
        try {
            gamesList = DataFetcher.fetchLOTRGames();

            FXMLLoader loader = new FXMLLoader(getClass().getResource("MainLayout.fxml"));
            Parent root = loader.load();

            MainController controller = loader.getController();
            controller.initData(gamesList);

            Scene scene = new Scene(root, 800, 600);

            primaryStage.setScene(scene);
            primaryStage.setTitle("Lord of the Rings Games Last 20 years");

            Image icon = new Image("/ring.png");
            primaryStage.getIcons().add(icon);

            primaryStage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        launch(args);
    }
}